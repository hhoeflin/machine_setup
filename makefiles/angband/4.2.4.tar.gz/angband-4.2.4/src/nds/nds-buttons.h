#ifndef _NDS_BUTTONS_H
#define _NDS_BUTTONS_H

void nds_btn_vblank();
void nds_btn_init();

#endif