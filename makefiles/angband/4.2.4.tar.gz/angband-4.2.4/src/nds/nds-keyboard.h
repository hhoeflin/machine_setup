#ifndef _NDS_KEYBOARD_H
#define _NDS_KEYBOARD_H

#include "../h-basic.h"

bool nds_kbd_init();
void nds_kbd_vblank();

#endif