#ifndef _NDS_SCREENKEYS_H
#define _NDS_SCREENKEYS_H

void nds_scrkey_vblank();
void nds_scrkey_init();

#endif
