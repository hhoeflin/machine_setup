#ifndef _NDS_SLOT2_VIRT_H
#define _NDS_SLOT2_VIRT_H

#include "../h-basic.h"

#ifndef __3DS__
void mem_init_alt(void);
#endif

#endif
