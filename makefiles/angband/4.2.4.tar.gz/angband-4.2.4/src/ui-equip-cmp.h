/**
 * \file ui-equip-cmp.h
 * \brief Declare interface for "resistance grid for home"
 */

#ifndef UI_EQUIP_CMP_H
#define UI_EQUIP_CMP_H

void equip_cmp_display(void);

#endif /* !UI_EQUIP_CMP_H */
