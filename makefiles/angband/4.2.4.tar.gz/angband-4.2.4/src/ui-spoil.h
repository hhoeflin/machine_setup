/**
 * \file ui-spoil.h
 * \brief Declarations for menu to generate spoiler files
 */
#ifndef INCLUDED_UI_SPOIL_H
#define INCLUDED_UI_SPOIL_H

void do_cmd_spoilers(void);

#endif /* INCLUDED_UI_SPOIL_H */
